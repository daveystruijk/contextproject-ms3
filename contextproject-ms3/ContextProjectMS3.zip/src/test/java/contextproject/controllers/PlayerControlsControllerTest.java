package contextproject.controllers;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PlayerControlsControllerTest {

  @Test
  public void test() {
    PlayerControlsController controller = new PlayerControlsController();
    assertEquals(controller, controller);
    
  }

}
