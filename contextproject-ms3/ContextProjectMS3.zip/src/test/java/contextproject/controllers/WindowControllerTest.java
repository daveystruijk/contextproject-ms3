package contextproject.controllers;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class WindowControllerTest {

  @Test
  public void test() {
    WindowController window = new WindowController();
    assertEquals(window, window);
  }
}
