package contextproject.helpers;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class FileNameTest {

  @Test
  public void test() {
    FileName fileName = new FileName();
    assertEquals(fileName, fileName);
  }

}
