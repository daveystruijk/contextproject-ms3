package contextproject;


public class AppConfig {
  public static boolean gui = true;
  public static boolean useAirhornTransition = false;
  public static boolean maxFlowSorter = true;
  
  public static final int maxFlowDepth = 10;
}
